# Upload Platform Architecture Pack — v1.0-rc2

包含：
- Architecture Design v1.0-rc2
- Database Schema v1（字段类型、外键、索引、迁移顺序、事务边界）
- OpenAPI 3.1 REST API 契约
- Adapter Request / Event / Result JSON Schema Draft 2020-12
- 第三轮架构 Review 报告

这是 Review Candidate，不是已冻结的生产实现。OpenAPI、JSON Schema 和 SQLite DDL 必须通过对应自动验证后才能冻结 v1.0。
