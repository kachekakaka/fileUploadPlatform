# Database Schema v1 --- Upload Platform

**状态：** v1.0-rc2 候选。SQLite 3.37+；Alembic revision 管理迁移。

## 1. 类型约定

-   UUID：规范化小写 UUID `TEXT`。
-   UTC 时间：Unix epoch milliseconds `INTEGER`；API 使用 RFC3339。
-   Boolean：`INTEGER CHECK(value IN (0,1))`。
-   JSON：`TEXT`，应用层 Pydantic 校验；可加 `json_valid()`。
-   SHA-256：64 位小写十六进制 `TEXT`。
-   大小：非负 `INTEGER`。
-   表使用 STRICT（部署 SQLite 版本必须支持）。
-   不存明文 Cookie、Token、App Secret。

## 2. 表结构

### accounts

`account_id TEXT PK`, `platform TEXT NOT NULL`,
`external_account_id TEXT NOT NULL`, `display_name TEXT`,
`status TEXT CHECK IN (ACTIVE,DISABLED,AUTH_REQUIRED,ERROR)`,
`credential_ref TEXT NOT NULL`,
`concurrency_limit INTEGER NOT NULL DEFAULT 1 CHECK >=1`,
`created_at INTEGER NOT NULL`, `updated_at INTEGER NOT NULL`,
`UNIQUE(platform, external_account_id)`.

### workers

`worker_id TEXT PK`, `hostname TEXT NOT NULL`, `boot_id TEXT NOT NULL`,
`runtime_role TEXT CHECK IN (WORKER,SCHEDULER,COMBINED)`,
`status TEXT CHECK IN (ONLINE,DRAINING,OFFLINE,QUARANTINED)`,
`process_id INTEGER`, `process_start_identity TEXT`,
`started_at INTEGER NOT NULL`, `heartbeat_at INTEGER NOT NULL`,
`last_seen_at INTEGER NOT NULL`, `capabilities_json TEXT NOT NULL`. PID
必须与 boot identity 和 process start identity 配合使用。

### schedules

`schedule_id TEXT PK`, `name TEXT NOT NULL`,
`status TEXT CHECK IN (ACTIVE,PAUSED,DISABLED,COMPLETED)`,
`schedule_type TEXT CHECK IN (ONCE,DAILY,WEEKLY,CRON)`,
`timezone TEXT NOT NULL`, `recurrence_rule TEXT`,
`revision INTEGER NOT NULL CHECK >=1`, `next_fire_at INTEGER`,
`misfire_policy TEXT CHECK IN (RUN_IMMEDIATELY,SKIP,EXPIRE)`,
`max_lateness_seconds INTEGER NULL CHECK >=0`,
`execution_template_json TEXT NOT NULL`, `created_at INTEGER NOT NULL`,
`updated_at INTEGER NOT NULL`.

### schedule_runs

`schedule_run_id TEXT PK`,
`schedule_id TEXT NOT NULL FK schedules ON DELETE RESTRICT`,
`occurrence_key TEXT NOT NULL`, `schedule_revision INTEGER NOT NULL`,
`scheduled_fire_at INTEGER NOT NULL`,
`status TEXT CHECK IN (PLANNED,GENERATED,SKIPPED,EXPIRED,FAILED)`,
`processed_at INTEGER`, `error_code TEXT`,
`created_at INTEGER NOT NULL`, `UNIQUE(schedule_id, occurrence_key)`.
不设置 generated_task_id；权威关联由 tasks.schedule_run_id 持有。

### assets

`asset_id TEXT PK`,
`source_type TEXT CHECK IN (LOCAL_UPLOAD,LOCAL_PATH_IMPORT,OBJECT_STORAGE)`,
`storage_reference TEXT NOT NULL UNIQUE`,
`original_filename TEXT NOT NULL`, `media_type TEXT NOT NULL`,
`file_size INTEGER NOT NULL CHECK >=0`,
`sha256 TEXT NOT NULL CHECK length=64`,
`status TEXT CHECK IN (REGISTERED,VALIDATING,STAGING,AVAILABLE,FAILED,CLEANUP_PENDING,DELETED)`,
`immutable INTEGER NOT NULL DEFAULT 1 CHECK IN (0,1)`,
`retention_until INTEGER`, `created_at INTEGER NOT NULL`,
`verified_at INTEGER`, `deleted_at INTEGER`. 不对 SHA-256 做全局唯一。

### tasks

`task_id TEXT PK`, `external_id TEXT`, `platform TEXT NOT NULL`,
`account_id TEXT NOT NULL FK accounts ON DELETE RESTRICT`,
`schedule_run_id TEXT UNIQUE NULL FK schedule_runs ON DELETE RESTRICT`,
`execution_type TEXT CHECK IN (IMMEDIATE,SCHEDULED,RECURRING)`,
`status TEXT CHECK IN (QUEUED,CLAIMED,VALIDATING,RUNNING,RECOVERY_PENDING,RETRY_WAIT,PAUSED,SUCCEEDED,FAILED,UNCERTAIN,CANCELLED,EXPIRED,QUARANTINED)`,
`priority INTEGER NOT NULL DEFAULT 0 CHECK BETWEEN 0 AND 100`,
`scheduled_at INTEGER NOT NULL`, `deadline_at INTEGER`,
`deadline_mode TEXT CHECK IN (START_BEFORE,COMPLETE_BEFORE)`,
`metadata_json TEXT NOT NULL`, `options_json TEXT NOT NULL`,
`attempt_count INTEGER NOT NULL DEFAULT 0 CHECK >=0`,
`max_attempts INTEGER NOT NULL DEFAULT 3 CHECK >=1`,
`next_attempt_at INTEGER`, `cancel_requested_at INTEGER`,
`created_at INTEGER NOT NULL`, `updated_at INTEGER NOT NULL`,
`started_at INTEGER`, `completed_at INTEGER`, `last_error_class TEXT`,
`last_error_message_redacted TEXT`.

不冗余保存 current_attempt_id；通过 Attempt 查询和 partial unique index
约束活动 Attempt。

### task_assets

`task_id TEXT NOT NULL FK tasks ON DELETE RESTRICT`,
`asset_id TEXT NOT NULL FK assets ON DELETE RESTRICT`,
`asset_role TEXT CHECK IN (VIDEO,COVER,SUBTITLE,ATTACHMENT)`,
`sort_order INTEGER NOT NULL DEFAULT 0 CHECK >=0`,
`created_at INTEGER NOT NULL`,
`PRIMARY KEY(task_id,asset_id,asset_role)`,
`UNIQUE(task_id,asset_role,sort_order)`.

### attempts

`attempt_id TEXT PK`,
`task_id TEXT NOT NULL FK tasks ON DELETE RESTRICT`,
`attempt_number INTEGER NOT NULL CHECK >=1`,
`worker_id TEXT FK workers ON DELETE RESTRICT`,
`adapter_name TEXT NOT NULL`, `adapter_version TEXT NOT NULL`,
`protocol_version INTEGER NOT NULL`,
`status TEXT CHECK IN (CREATED,STARTING,RUNNING,RETRYABLE_FAILURE,PERMANENT_FAILURE,SUCCEEDED,UNCERTAIN,CANCELLED)`,
`phase TEXT NOT NULL`,
`remote_operation_started INTEGER NOT NULL DEFAULT 0 CHECK IN (0,1)`,
`host_boot_id TEXT`, `process_id INTEGER`,
`process_start_identity TEXT`, `execution_handle TEXT`,
`checkpoint_ref TEXT`, `result_ref TEXT`, `started_at INTEGER`,
`heartbeat_at INTEGER`, `finished_at INTEGER`, `error_class TEXT`,
`error_message_redacted TEXT`, `UNIQUE(task_id,attempt_number)`.

### lease_counters

`scope_type TEXT CHECK IN (TASK,ACCOUNT_SLOT)`,
`scope_id TEXT NOT NULL`, `slot_number INTEGER NOT NULL DEFAULT 0`,
`last_fencing_token INTEGER NOT NULL DEFAULT 0 CHECK >=0`,
`PRIMARY KEY(scope_type,scope_id,slot_number)`.

### task_leases

`lease_id TEXT PK`, `task_id TEXT NOT NULL FK tasks`,
`attempt_id TEXT NOT NULL FK attempts`,
`worker_id TEXT NOT NULL FK workers`,
`lease_token TEXT NOT NULL UNIQUE`,
`fencing_token INTEGER NOT NULL CHECK >0`,
`acquired_at INTEGER NOT NULL`, `heartbeat_at INTEGER NOT NULL`,
`expires_at INTEGER NOT NULL`, `released_at INTEGER`,
`UNIQUE(task_id,fencing_token)`.

### account_leases

`lease_id TEXT PK`, `account_id TEXT NOT NULL FK accounts`,
`slot_number INTEGER NOT NULL CHECK >=0`,
`attempt_id TEXT NOT NULL FK attempts`,
`worker_id TEXT NOT NULL FK workers`,
`lease_token TEXT NOT NULL UNIQUE`,
`fencing_token INTEGER NOT NULL CHECK >0`,
`acquired_at INTEGER NOT NULL`, `heartbeat_at INTEGER NOT NULL`,
`expires_at INTEGER NOT NULL`, `released_at INTEGER`,
`UNIQUE(account_id,slot_number,fencing_token)`.

### events

`event_id TEXT PK`, `entity_type TEXT NOT NULL`,
`entity_id TEXT NOT NULL`, `task_id TEXT FK tasks`,
`attempt_id TEXT FK attempts`, `sequence INTEGER NOT NULL CHECK >=1`,
`event_type TEXT NOT NULL`, `payload_json TEXT NOT NULL`,
`schema_version INTEGER NOT NULL`, `created_at INTEGER NOT NULL`,
`UNIQUE(entity_type,entity_id,sequence)`.

### outbox_events

`outbox_id TEXT PK`, `event_id TEXT NOT NULL UNIQUE FK events`,
`status TEXT CHECK IN (PENDING,PUBLISHED,DEAD_LETTER)`,
`attempts INTEGER NOT NULL DEFAULT 0`, `available_at INTEGER NOT NULL`,
`published_at INTEGER`, `last_error_redacted TEXT`.

### receipts

`receipt_id TEXT PK`, `task_id TEXT NOT NULL UNIQUE FK tasks`,
`attempt_id TEXT NOT NULL FK attempts`, `platform TEXT NOT NULL`,
`account_id TEXT NOT NULL FK accounts`, `remote_id TEXT NOT NULL`,
`remote_url TEXT`, `result_digest TEXT NOT NULL CHECK length=64`,
`evidence_type TEXT CHECK IN (ADAPTER_RESULT,REMOTE_VERIFICATION,MANUAL_VERIFICATION)`,
`verification_status TEXT CHECK IN (VERIFIED,PENDING_REVIEW)`,
`completed_at INTEGER NOT NULL`, `receipt_json TEXT NOT NULL`. 仅
VERIFIED Receipt 可以令 Task 进入 SUCCEEDED。

### asset_operations

`operation_id TEXT PK`, `asset_id TEXT NOT NULL FK assets`,
`operation_type TEXT CHECK IN (STAGE,VERIFY,CLEANUP,IMPORT)`,
`status TEXT CHECK IN (PLANNED,RUNNING,COMPLETED,FAILED)`,
`source_ref TEXT`, `destination_ref TEXT`,
`idempotency_key TEXT NOT NULL UNIQUE`, `created_at INTEGER NOT NULL`,
`updated_at INTEGER NOT NULL`, `error_redacted TEXT`.

### idempotency_keys

`idempotency_key TEXT PK`, `scope TEXT NOT NULL`,
`request_hash TEXT NOT NULL`, `resource_type TEXT NOT NULL`,
`resource_id TEXT NOT NULL`, `response_status INTEGER NOT NULL`,
`response_json TEXT NOT NULL`, `created_at INTEGER NOT NULL`,
`expires_at INTEGER`.

### credentials

`credential_id TEXT PK`, `account_id TEXT NOT NULL FK accounts`,
`secret_backend TEXT NOT NULL`, `secret_reference TEXT NOT NULL`,
`credential_version INTEGER NOT NULL`,
`status TEXT CHECK IN (ACTIVE,ROTATING,EXPIRED,REVOKED,ERROR)`,
`created_at INTEGER NOT NULL`, `updated_at INTEGER NOT NULL`,
`UNIQUE(account_id,credential_version)`. 密文保存在加密 Secret Backend。

## 3. 索引

``` sql
CREATE INDEX ix_tasks_due ON tasks(status, scheduled_at, priority DESC, created_at);
CREATE INDEX ix_tasks_retry_due ON tasks(status, next_attempt_at) WHERE status = 'RETRY_WAIT';
CREATE UNIQUE INDEX ux_task_active_lease ON task_leases(task_id) WHERE released_at IS NULL;
CREATE UNIQUE INDEX ux_account_active_slot_lease ON account_leases(account_id, slot_number) WHERE released_at IS NULL;
CREATE UNIQUE INDEX ux_attempt_one_active ON attempts(task_id) WHERE status IN ('CREATED','STARTING','RUNNING');
CREATE INDEX ix_schedule_runs_due ON schedule_runs(status, scheduled_fire_at);
CREATE INDEX ix_task_assets_asset ON task_assets(asset_id);
CREATE INDEX ix_events_task_sequence ON events(task_id, sequence);
CREATE INDEX ix_outbox_due ON outbox_events(status, available_at);
CREATE INDEX ix_assets_cleanup ON assets(status, retention_until);
```

UNCERTAIN Attempt 是终态，但 Task UNCERTAIN 阻止自动创建新
Attempt。人工处置必须先完成审计转换。

## 4. 迁移顺序

1.  `0001_foundation`：accounts、workers。
2.  `0002_assets_credentials`：assets、asset_operations、credentials。
3.  `0003_scheduling`：schedules、schedule_runs。
4.  `0004_tasks_attempts`：tasks、attempts、task_assets。
5.  `0005_leases`：lease_counters、task_leases、account_leases。
6.  `0006_events_receipts`：events、outbox_events、receipts。
7.  `0007_idempotency_indexes`：idempotency_keys、索引。
8.  `0008_integrity_guards`：经测试后加入的触发器/约束补强。

已发布 migration 不可修改；只能追加
revision。破坏性迁移必须备份、审批并提供恢复方案。

## 5. 事务边界

-   T1 Create Task：幂等记录、Task、TaskAsset、Event、Outbox 同事务。
-   T2 Materialize ScheduleRuns：插入 PLANNED occurrence 并推进
    next_fire_at。
-   T3 Generate Task：ScheduleRun 检查、Task 插入、ScheduleRun
    GENERATED、Event/Outbox 同事务。
-   T4 Claim：Task、Account Slot、Attempt、两类 Lease、fencing counter
    同事务。
-   T5 Start Adapter：先持久化 STARTING / execution
    intent；进程启动在事务外；随后持久化进程身份。启动窗口不明时保守恢复。
-   T6 Heartbeat：条件 UPDATE，验证 lease_token、fencing_token
    和未释放状态。
-   T7 Event：验证后插入 Event + Outbox，sequence 冲突隔离。
-   T8 Completion：事务外验证 Adapter result；事务内验证 Lease、写
    Receipt、Attempt/Task
    终态、Event/Outbox。只有进程退出且远端策略允许后才释放账号 slot。
-   T9 Asset Cleanup：事务内登记意图，事务外删文件，事务内确认。
-   T10 Recovery：短事务认领 recovery
    operation；事务外检查进程/证据；事务内条件提交结果。

任何事务内禁止网络请求、文件复制、哈希计算、sleep 或等待子进程。
