# Upload Platform --- Architecture Design v1.0-rc2

**定位：** 独立应用 + REST API / Python SDK / CLI / Web Dashboard\
**架构：** Modular Monolith\
**首批平台：** Bilibili、Baidu Netdisk\
**部署：** 单主机 Docker Compose；API Server 与 Worker Runtime
分角色启动\
**状态：** Review Candidate，尚未冻结。

## 1. 架构原则

1.  Core 自主维护；平台实现通过 Adapter 契约接入。
2.  Schedule、ScheduleRun、Task、Attempt、Asset、Account、Worker、Lease
    是独立领域实体。
3.  执行资格、状态和远端操作证据必须持久化。
4.  网络请求、文件复制、哈希计算和 Adapter 执行不得位于数据库写事务内。
5.  Lease 到期不代表远端操作已停止。
6.  Fencing Token 保护本地状态提交，不会自动 fencing 第三方平台。
7.  无法证明安全重试时进入 UNCERTAIN。
8.  SUCCEEDED 必须有平台特定且可验证的 Receipt。
9.  API、CLI、SDK、Dashboard 共用 Application Services；Dashboard
    不直连数据库。
10. SQLite WAL 仅用于同一主机本地可靠文件系统。

## 2. 模块边界

-   Application：REST API、SDK facade、CLI、Dashboard query services。
-   Domain：Task、Schedule、ScheduleRun、Attempt、Account、Asset、Lease、Receipt
    及状态转换。
-   Scheduling：Schedule Evaluator、Due Dispatcher、Task Dispatcher。
-   Execution：Worker Supervisor、Lease
    Manager、Heartbeat、进程监督、事件采集、结果提交。
-   Adapter：Native Python / Subprocess
    Adapter；平台细节封装在各自实现中。
-   Asset Manager：文件登记、验证、暂存、不可变性、引用追踪和清理。
-   Credential Manager：凭据加密存储、刷新、验证、轮换和审计。
-   Persistence / Observability：Repository、Unit of Work、Event
    Store、Outbox、Receipt Store、结构化日志。

Domain 不得依赖 FastAPI、SQLAlchemy、SQLite、httpx 或具体平台
Adapter。Adapter 不得直接写 Core 数据库。Dashboard 只能通过 REST/SSE
访问数据。

## 3. Runtime

初始部署包含两个启动角色：

-   API Server：REST、认证、查询、SSE、Application Services。
-   Worker Runtime：Scheduler、Dispatcher、Worker Supervisor、Adapter
    Host、Recovery。

两者运行在同一主机，访问本地 SQLite 和受控存储卷。未来多主机必须迁移
PostgreSQL，并重新设计共享 Asset Storage、Worker fencing
和账号执行所有权；不得跨主机共享 SQLite WAL。

## 4. 领域模型

### Schedule

定时规则和执行模板。Schedule 状态不决定已生成 Task 的状态。字段包括
timezone、recurrence_rule、revision、next_fire_at、misfire_policy、max_lateness_seconds。

### ScheduleRun

某个 Schedule revision 的一次触发点。唯一身份
`(schedule_id, occurrence_key)`。状态：PLANNED、GENERATED、SKIPPED、EXPIRED、FAILED。一个
ScheduleRun 最多生成一个 Task。

### Task

一次业务上传意图。即时、一次性定时、周期触发任务共用队列。`scheduled_at`
是最早允许执行时间；`deadline_at` 必须配合 `deadline_mode`（START_BEFORE
/ COMPLETE_BEFORE）。

### Attempt

一次执行尝试。重试创建新 Attempt，不复用旧 Attempt。记录 Adapter
版本、Worker、执行阶段、远端操作边界、checkpoint 和结果引用。

### Asset / TaskAsset

Asset 是文件实体；TaskAsset 是 Task 对 Asset 的角色化引用。一个 Asset
可被多个 Task 复用。清理需检查 Task 引用、活动 Attempt、Recovery
和保留期限。

### Account / Worker / Lease

Account 使用内部 UUID，外部 MID/UID 仅作平台身份字段。Task Lease
保护任务所有权；Account Slot Lease 保护账号并发额度。MVP 默认每账号一个
slot。

### Receipt

远端成功的持久证据。一个 Task 最多一个最终成功
Receipt；机器确认与人工核验必须区分证据来源。

## 5. 调度语义

支持 Immediate、One-time Scheduled、Recurring（Daily / Weekly / Cron）。

绝对时间存 UTC；周期规则保留 IANA timezone。DST 策略： -
不存在的本地时间：跳过并记录 SKIPPED。 -
重复的本地时间：默认执行第一次实际发生的时刻。 - occurrence_key
使用规范化 UTC instant，不能只用本地时间字符串。

Misfire：RUN_IMMEDIATELY、SKIP、EXPIRE；由 max_lateness_seconds
限制补执行窗口。Schedule 修改增加 revision；已生成 Task
不因后续修改而改变。

Schedule Evaluator 在短事务内物化 PLANNED ScheduleRun 并推进
next_fire_at。Due Dispatcher 在一个短事务中检查 Schedule、处理
misfire、插入 Task、将 ScheduleRun 更新为 GENERATED、写入 Event/Outbox
并提交。`UNIQUE(schedule_id, occurrence_key)` 和
`UNIQUE(tasks.schedule_run_id)` 防止重复生成。

## 6. Worker Ownership / Lease / Fencing

Task Lease 保护单个 Task 的执行所有权；Account Slot Lease 保护账号并发
slot。两种 Lease 的获取必须在同一短事务中完成，并创建
Attempt。fencing_token 对每个 scope/slot
单调递增，永不重置。所有终态提交必须验证当前 lease_token 和
fencing_token。

Heartbeat 由 Worker Supervisor 发出，不由 Adapter 自行续租。Lease
到期仅触发 RECOVERY_PENDING，不自动释放账号 slot 或重排 Task。

Recovery： 1. 阻止新执行获得冲突 Account Slot。 2. 检查 Worker、主机
boot_id、PID start identity、进程组/cgroup。 3. 受控终止残留 Adapter
Host 并确认进程退出。 4. 校验 Attempt events、checkpoint、result
和远端阶段。 5. Adapter
未启动可安全重排；已启动时只有证据证明远端副作用未发生才可自动重试。 6.
媒体上传可续传时，验证 checkpoint、账号和 Asset 指纹后恢复。 7.
最终提交请求可能已发送且无可靠远端查询证据时进入 UNCERTAIN。 8. 有效
Receipt 存在时恢复 SUCCEEDED。

Fencing 不能阻止旧进程向远端发请求。远端无幂等键时不承诺 exactly-once。

## 7. SQLite 事务

SQLite 3.37+，STRICT
tables、WAL、foreign_keys、synchronous=FULL、busy_timeout。数据库放本机可靠文件系统。

-   Task 创建、ScheduleRun 生成、Lease 获取、Attempt
    创建、事件写入和终态提交使用短事务。
-   文件复制、哈希、HTTP、Adapter
    执行、sleep、等待进程均不得持有写事务。
-   竞争性认领使用 BEGIN IMMEDIATE 或条件 UPDATE/RETURNING。
-   SQLITE_BUSY 有限退避；超限后返回可观察错误。
-   Event 与 Outbox 同事务写入；发布为 at-least-once，消费者按 event_id
    去重。
-   备份使用 SQLite Online Backup API 或一致性快照，不能只复制主 DB
    文件而忽略 WAL。

## 8. Asset 生命周期

长期定时任务默认使用应用控制的 staged
asset。登记时验证类型、大小、路径、链接策略和
SHA-256。暂存完成后原子登记 AVAILABLE。

清理流程：事务中创建 asset_operation 并标记
CLEANUP_PENDING；事务外删除文件；事务中确认
DELETED。清理必须幂等，新增引用必须阻止删除。不要仅凭手工维护的
reference_count 清理。

## 9. Adapter Execution

所有上传由独立 Adapter Execution Host 执行。Native Python Adapter
也运行在受监督的独立进程中；Subprocess Adapter 使用固定 argv、受限环境和
opaque credential reference。

Supervisor 负责
Lease、Heartbeat、进程监督、事件采集、取消、结果验证和状态提交。Adapter
负责平台 preflight、上传、进度、阶段事件、checkpoint 和平台恢复。

取消是请求，不是终态。远端提交可能发生时取消结果应为 UNCERTAIN。

## 10. Event / Outbox

每个 aggregate 的 sequence 单调递增。状态变更与 Event/Outbox
在同一事务提交。Outbox 发布为 at-least-once；SSE 支持
Last-Event-ID，客户端按 event_id 去重。事件必须脱敏。

## 11. API / Security / Third-party

REST API 是公开契约，前缀 `/api/v1`。SDK 包装公开 Schema；CLI 和
Dashboard 调用相同 Application Services。创建接口支持
Idempotency-Key。远程 API
不得接受任意服务器绝对路径；本地路径导入只允许受控 CLI/本机接口。

凭据不得放入 Task
metadata、事件或日志。第三方依赖必须固定版本/commit、记录许可证、patch、测试、升级和移除策略。Core
不依赖第三方内部模块、CLI 文本或数据库。

## 12. 部署与阶段

MVP：单主机 Docker Compose；API Server 与 Worker Runtime
分角色启动，共享本地 SQLite 和受控卷。未来多机需要
PostgreSQL、共享/对象存储及重新审查的 fencing 协议。

Phase 0：架构、ER、DB 约束、OpenAPI、Adapter JSON
Schema、ADR、旧项目审计。\
Phase 1：Fake
Adapter、即时/定时/周期任务、持久队列、Lease、事件、Recovery、API/CLI、并发与故障注入。\
Phase 2：Bilibili Adapter。\
Phase 3：Baidu Adapter。\
Phase 4：Dashboard、通知、运维与备份。

本文件是 rc2 候选，不代表生产上传已获批准。
