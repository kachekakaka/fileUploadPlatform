# Third Architecture Review --- v1.0-rc2

## 结论

**有条件通过进入 Schema / 原型验证；暂不冻结 v1.0。**

## 1. 数据库事务 Review

1.  **ScheduleRun 双向外键：** 不应在 ScheduleRun 和 Task
    同时保存互相指向的外键。rc2 只保留
    `tasks.schedule_run_id UNIQUE FK`。
2.  **Claim 事务：** Task Lease 与 Account Slot Lease
    必须同一事务创建。事务内检查账号 slot、递增 fencing counter、插入
    Lease、Attempt、更新 Task。任何一步失败整体回滚。
3.  **终态提交与进程存活：** 不能仅凭 Adapter result 文件存在就释放
    Account Lease。Supervisor 应确认执行进程退出，验证
    result/events，验证 lease generation，再提交 Receipt 和终态。
4.  **Receipt 原子性：** Receipt、Attempt SUCCEEDED、Task
    SUCCEEDED、Event、Outbox 同一事务。文件证据先原子落盘并
    fsync，再在事务中记录引用。
5.  **Outbox：** 状态变更与 Event/Outbox 同事务。Publisher 为
    at-least-once；消费者按 event_id 幂等。
6.  **SQLite 并发：**
    禁止长事务、网络请求、sleep、hash、大文件复制在事务内。必须做多进程压力测试。

## 2. 跨模块依赖 Review

依赖方向：

`Apps (API/CLI) -> Application Services -> Domain`

`Application Services -> Ports (Repository, UnitOfWork, Scheduler, AdapterRegistry, AssetStore, CredentialStore, EventPublisher)`

`Infrastructure -> implements Ports`

`Adapters -> Adapter SDK / Execution Context`

约束： - Domain 不 import FastAPI、SQLAlchemy、SQLite、httpx、具体
Adapter 或 Dashboard 类型。 - Adapter 不 import Core Repository，不写
Core 数据库。 - Dashboard 不访问数据库或本机媒体目录。 - Task Engine 不
import Scheduler 实现；Scheduler 通过 TaskSubmissionPort 创建任务。 -
Adapter Registry 不 import 具体 Adapter；由 composition root
注册实现。 - 通过 Ports 避免模块循环依赖。

## 3. 异常恢复 Review

1.  Heartbeat timeout 只触发 RECOVERY_PENDING。先检查 host boot_id、PID
    start identity、进程组/cgroup，并受控终止残留 Adapter Host。
2.  主机断电后，本地进程消失不代表远端请求未完成。媒体阶段按 Adapter
    checkpoint 恢复；最终提交阶段无远端证据时 UNCERTAIN。
3.  Adapter 启动窗口先持久化 STARTING / execution intent。PID
    未写入不代表进程未启动；无法证明未启动时禁止自动重试。
4.  旧 Worker 本地写入由 fencing token 拒绝。远端请求无法被本地 fencing
    阻止；Account Slot 只有在旧执行 Host 确认终止或风险核验后才释放。
5.  Asset Cleanup 先持久化 PLANNED，再事务外删除，再标记
    COMPLETED。清理幂等，路径身份和 checksum 必须核验。
6.  SQLite 与文件系统没有共同事务。所有文件操作使用 operation
    journal：先登记意图、事务外原子操作、再更新状态。冲突证据保留。

## 4. Schema 修正清单

-   UUID 用规范化 TEXT；时间用 UTC epoch milliseconds；JSON 用 TEXT +
    应用层校验；布尔用 0/1 CHECK。
-   `tasks.schedule_run_id` 是唯一权威关联，允许 NULL。
-   不冗余 `current_attempt_id`。
-   active Attempt partial index 仅包含
    CREATED、STARTING、RUNNING；UNCERTAIN 由 Task 状态阻止自动重试。
-   Lease 历史保留；过期但未完成 Recovery 的 Lease 不得简单标记释放。
-   不对 Asset SHA-256 全局唯一。
-   deadline 必须有 START_BEFORE / COMPLETE_BEFORE 语义。
-   Schedule revision 更新要处理未来 PLANNED ScheduleRun。
-   CHECK 枚举与迁移版本同步。

## 5. API Review

-   OpenAPI 3.1 是 REST 契约；SDK 从契约生成或校验。
-   metadata 按 platform + adapter schema 验证。
-   Idempotency-Key 绑定 scope、request_hash、响应资源；相同 key 不同
    body 返回 409。
-   Cancel 返回 202 和 cancel_requested，不谎称已经取消。
-   SSE at-least-once，Last-Event-ID + event_id 去重。
-   不接受明文 Cookie/Token。
-   远程 REST 不允许任意服务器绝对路径；本地路径导入仅限受控
    CLI/本机接口。

## 6. Adapter Schema Review

-   Request、Event、Result 使用 JSON Schema Draft 2020-12。
-   消息绑定 task_id、attempt_id、attempt_number、fencing_token。
-   Credential 只能是 opaque reference。
-   Event sequence 严格递增；重复 event_id 幂等；同 sequence
    不同内容是协议冲突。
-   retryable_failure 必须证明 remote_operation_started=false。
-   success 需要 remote_id，且平台验证器进一步确认。
-   uncertain 不得自动重试。
-   Adapter 不得设置 Task 终态或释放 Lease。

## 7. v1.0 冻结阻断项

1.  在目标 SQLite 版本执行真实 DDL 和约束测试。
2.  OpenAPI YAML 通过 OpenAPI 3.1 validator。
3.  JSON Schema 通过 Draft 2020-12 validator，并加入正反例。
4.  明确 RECOVERY_PENDING 是 Task 持久状态还是 Recovery Operation；rc2
    暂定 Task 持久状态。
5.  Claim / Heartbeat / Completion / ScheduleRun / Asset cleanup
    多进程故障注入。
6.  Adapter Host 启动窗口、SIGKILL、主机重启测试。
7.  旧项目逐模块审计后才决定迁移或重写。

**最终意见：** rc2 可进入实现原型阶段；数据库 DDL、OpenAPI 和 Adapter
JSON Schema 自动验证通过后，才能标记 v1.0 frozen。
